const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { createAuditLog } = require('./audit.controller');
const connectDB = require('../config/database');

const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-key';
const DEMO_USERS = [
  {
    id: 'demo-analyst-1',
    email: 'analyst@fraudshield.com',
    password: 'Analyst@123',
    name: 'Emily Davis',
    role: 'analyst',
    department: 'Fraud Analysis',
    status: 'active'
  },
  {
    id: 'demo-analyst-2',
    email: 'analyst2@fraudshield.com',
    password: 'Analyst@456',
    name: 'James Wilson',
    role: 'analyst',
    department: 'Risk Assessment',
    status: 'active'
  },
  {
    id: 'demo-admin-1',
    email: 'admin@fraudshield.com',
    password: 'Admin@123',
    name: 'Sarah Johnson',
    role: 'admin',
    department: 'Security Operations',
    status: 'active'
  }
];

// Helper function to generate JWT
const generateToken = (user, expiresIn = '24h') => {
  return jwt.sign(
    {
      userId: user._id || user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      status: user.status || 'active'
    },
    JWT_SECRET,
    { expiresIn }
  );
};

// Sign up controller
exports.signup = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Validation
    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and password are required'
      });
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email format'
      });
    }

    // Password strength validation
    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters'
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: 'Email already registered'
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new user
    const newUser = new User({
      email: email.toLowerCase(),
      password: hashedPassword,
      name: name,
      role: 'user'
    });

    await newUser.save();

    // Log the signup event
    await createAuditLog({
      action: 'User Signup',
      actor: newUser._id,
      actorName: newUser.name,
      target: newUser.email,
      ipAddress: req.ip,
      result: 'Success'
    });

    // Generate JWT token
    const token = generateToken(newUser);

    // Return success response
    res.status(201).json({
      success: true,
      message: 'Account created successfully',
      token: token,
      user: {
        id: newUser._id,
        email: newUser.email,
        name: newUser.name,
        role: newUser.role
      }
    });

  } catch (error) {
    console.error('Sign-up error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Sign in controller
exports.signin = async (req, res) => {
  try {
    const { email, password, rememberMe } = req.body;

    // Validation
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required'
      });
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email format'
      });
    }

    if (!connectDB.isConnected()) {
      const demoUser = DEMO_USERS.find(
        (user) => user.email === email.toLowerCase() && user.password === password
      );

      if (!demoUser) {
        return res.status(401).json({
          success: false,
          message: 'Database unavailable. Use demo analyst/admin credentials in temporary offline mode.'
        });
      }

      const tokenExpiration = rememberMe ? '7d' : '24h';
      const token = generateToken(demoUser, tokenExpiration);

      return res.status(200).json({
        success: true,
        message: 'Sign in successful (offline demo mode)',
        token,
        user: {
          id: demoUser.id,
          email: demoUser.email,
          name: demoUser.name,
          role: demoUser.role,
          department: demoUser.department,
          status: demoUser.status
        }
      });
    }

    // Find user by email
    const user = await User.findOne({ email: email.toLowerCase() });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    // Generate JWT token
    const tokenExpiration = rememberMe ? '7d' : '24h';
    const token = generateToken(user, tokenExpiration);

    // Log the signin event
    await createAuditLog({
      action: 'User Signin',
      actor: user._id,
      actorName: user.name,
      target: user.email,
      ipAddress: req.ip,
      result: 'Success'
    });

    // Return success response
    res.status(200).json({
      success: true,
      message: 'Sign in successful',
      token: token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        role: user.role
      }
    });

  } catch (error) {
    console.error('Sign-in error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get current user controller (protected route)
exports.getMe = async (req, res) => {
  try {
    res.status(200).json({
      success: true,
      user: req.user
    });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Logout controller
exports.logout = async (req, res) => {
  try {
    return res.status(200).json({
      success: true,
      message: 'Signed out successfully'
    });
  } catch (error) {
    console.error('Logout error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// OAuth success handler
// ...existing code...

// OAuth success handler
exports.oauthSuccess = async (req, res) => {
  const token = generateToken(req.user);
  const loginAs = req.loginAs || '';

  // Log the OAuth signin event
  await createAuditLog({
    action: 'OAuth Signin',
    actor: req.user._id,
    actorName: req.user.name,
    target: req.user.email,
    ipAddress: req.ip,
    details: { provider: req.user.provider || 'unknown', loginAs },
    result: 'Success'
  });

  // Redirect to frontend OAuth success page with token (and optional loginAs)
  const clientURL = process.env.CLIENT_URL || 'http://localhost:3000';
  const redirectUrl = `${clientURL}/oauth-success?token=${token}${
    loginAs ? `&loginAs=${loginAs}` : ''
  }`;

  res.redirect(redirectUrl);
};

// OAuth failure handler
// ...existing code...

// OAuth failure handler
exports.oauthFailure = (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Authentication Failed</title>
      <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-slate-900 to-zinc-900">
      <div class="text-center p-8 backdrop-blur-xl bg-white/10 rounded-3xl shadow-2xl border border-white/20 max-w-md">
        <div class="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-red-500 to-rose-600 rounded-full mb-6">
          <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
          </svg>
        </div>
        <h1 class="text-3xl font-bold text-white mb-4">Authentication Failed</h1>
        <p class="text-white/70 mb-6">Unable to complete sign-in. Please try again.</p>
        <a href="${process.env.CLIENT_URL || 'http://localhost:3000'}/signin" class="inline-block px-6 py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300">
          Back to Sign In
        </a>
      </div>
    </body>
    </html>
  `);
};
